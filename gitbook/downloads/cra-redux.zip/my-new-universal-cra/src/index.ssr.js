import { createSSRRender } from '@forrestjs/core/lib/create-ssr-render'

// project specific modules
import App from './App'
import './index.css'

import React from 'react'
import { Provider } from 'react-redux'
import createState from './redux-store'

const Root = ({ store, ...props }) => (
    <Provider store={store}>
        <App {...props} />
    </Provider>
)

export const staticRender = createSSRRender(Root, { createState })

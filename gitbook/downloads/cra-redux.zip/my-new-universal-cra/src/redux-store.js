import createSSRState from '@forrestjs/core/lib/create-ssr-state'

const app = () => ({
    name: 'My New Universal CRA',
})

export default createSSRState({ app })

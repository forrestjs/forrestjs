import { createSSRRender } from '@forrestjs/core/lib/create-ssr-render'

// project specific modules
import App from './App'
import './index.css'

export const staticRender = createSSRRender(App)

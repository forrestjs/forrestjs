const { runHookApp } = require('@forrestjs/hooks')

runHookApp({
    settings: ({ setConfig }) => {
        setConfig('expressGraphql.mountPoint', '/graphql')
    },
    features: [
        require('@forrestjs/service-express'),
        require('@forrestjs/service-express-graphql'),
        require('./home.route'),
        require('./welcome.query'),
    ]
})


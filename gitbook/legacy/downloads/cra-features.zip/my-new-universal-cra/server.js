// Makes NodeJS understand ES6
process.env.NODE_ENV = 'development'
require('@babel/polyfill')
require('@babel/register')

/**
 * polyfill "fetch" in NodeJS
 * this is used by your client app to make requests while rendering on the server
 */
require('es6-promise').polyfill()
require('isomorphic-fetch')

// List our server capabilities
const services = [
    require('@forrestjs/service-express'),
    require('@forrestjs/service-express-ssr'),
]

// Start the app
require('@forrestjs/hooks')
    .runHookApp(services)
    .catch(err => console.log(err.message))

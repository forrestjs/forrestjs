import React from 'react';
import logo from './logo.svg';
import './App.css';

import { connect } from 'react-redux';
import { UsersList } from './users-feature';

const mapState = ({ app }) => ({
  name: app.name,
});

function App({ name }) {
  return (
    <div className="App">
      <header className="App-header">
        <img src={logo} className="App-logo" alt="logo" />
        <p>
          Edit <code>src/App.js</code> and save to reload.
        </p>
        <a
          className="App-link"
          href="https://reactjs.org"
          target="_blank"
          rel="noopener noreferrer"
        >
          {name}
        </a>
      </header>
      <UsersList />
    </div>
  );
}

export default connect(mapState)(App);

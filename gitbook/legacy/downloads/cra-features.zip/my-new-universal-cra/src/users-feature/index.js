import users from './users.reducer'
import * as usersService from './users.service'

// exports the features capabilities:
export const reducers = { users }
export const services = [ usersService ]

// exports the UI entry point:
export { default as UsersList } from './UsersList'
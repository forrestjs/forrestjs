// Makes NodeJS understand ES6
process.env.NODE_ENV = 'development'
require('@babel/polyfill')
require('@babel/register')

// List our server capabilities
const services = [
    require('@forrestjs/service-express'),
    require('@forrestjs/service-express-ssr'),
]

// Start the app
require('@forrestjs/hooks')
    .runHookApp({ services })
    .catch(err => console.log(err.message))

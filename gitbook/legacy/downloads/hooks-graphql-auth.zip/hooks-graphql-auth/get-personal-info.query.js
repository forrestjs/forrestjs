const { GraphQLObjectType, GraphQLString } = require('graphql')

// Fake resolver, this should connect to some dbms and fetch
// very sensible data!
const resolve = () => ({
    name: 'Marco',
    surname: 'Pegoraro',
})

// Shape the GraphQL Type for our sensible data:
const GraphQLPesonalInfo = new GraphQLObjectType({
    name: 'PersonalInfo',
    fields: {
        name: { type: GraphQLString },
        surname: { type: GraphQLString },
    },
})

// Register the sensible query into the "auth" hook:
module.exports = [
    '$GRAPHQL_AUTH',
    ({ registerQuery }) => registerQuery('getPersonalInfo', {
        type: GraphQLPesonalInfo,
        resolve,
    }),
]

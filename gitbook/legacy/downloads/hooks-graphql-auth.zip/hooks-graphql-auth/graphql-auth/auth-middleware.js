const hooks = require('./hooks')

exports.authMiddleware = ({ registerMiddleware }, { getConfig, createHook }) => {
    // 1. Enforce settings and fail at boot time
    const validToken = getConfig('authToken', process.env.GRAPHQL_AUTH_TOKEN)

    // 2. Let other extensions mess up with the Business Logic
    let validateRequest = null
    let validateToken = null

    createHook.sync(hooks.GRAPHQL_VALIDATE, {
        setValidateRequest: fn => validateRequest = fn,
        setValidateToken: fn => validateToken = fn,
    })

    // 3. Provide a default Business Logic
    validateRequest = validateRequest || (req => {
        try {
            req.authToken = req.headers.authorization.substr(7)
            req.authTokenIsValid = req.authToken === validToken
        } catch (err) {
            req.authToken = null
            req.authTokenIsValid = false
        }
    })

    validateToken = validateToken || ((req, { token }) => {
        if (token) {
            req.authToken = token
            req.authTokenIsValid = token === validToken
        }
        return req.authTokenIsValid
    })

    // 4. Create the middleware
    registerMiddleware((req, res, next) => {
        validateRequest(req)
        req.authValidateToken = args => validateToken(req, args)
        next()
    })
}

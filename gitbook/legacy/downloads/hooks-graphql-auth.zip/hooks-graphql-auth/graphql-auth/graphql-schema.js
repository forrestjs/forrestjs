const { GraphQLObjectType, GraphQLID } = require('graphql')
const { GRAPHQL_AUTH } = require('./hooks')

// Delegates the task of validating the token to an Express Middleware
const canAccessAuth = (_, args, { req }) =>
    req.authValidateToken(args) ? true : null

exports.extendsGraphQLSchema = ({ registerQuery, registerMutation }, { createHook }) => {
    // Collect queries and mutations that needs session validation
    const queries = {}
    const mutations = {}
    const args = {
        token: {
            type: GraphQLID,
        }
    }

    // Let other features integrate their own queries and mutations.
    // It is always a good idea to provide getters/setters to the extensions
    // so to retain full control over the internal data structure:
    createHook(GRAPHQL_AUTH, {
        args: {
            registerQuery: (name, def) => queries[name] = def,
            registerMutation: (name, def) => mutations[name] = def,
            setArg: (key, val) => args[key] = val,
        },
    })

    // Extends the app's queries with the "auth" wrapper
    // (only if at least one query was registered)
    Object.keys(queries).length && registerQuery('auth', {
        args,
        type: new GraphQLObjectType({
            name: 'AuthQueryWrapper',
            fields: queries,
        }),
        resolve: canAccessAuth,
    })

    // Extends the app's mutations with the "auth" wrapper
    // (only if at least one mutation was registered)
    Object.keys(mutations).length && registerMutation('auth', {
        args,
        type: new GraphQLObjectType({
            name: 'AuthMutationWrapper',
            fields: mutations,
        }),
        resolve: canAccessAuth,
    })
}

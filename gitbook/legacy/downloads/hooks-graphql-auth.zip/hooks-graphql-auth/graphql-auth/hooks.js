const { FEATURE } = require('@forrestjs/hooks')
exports.FEATURE_NAME = `${FEATURE} graphql-auth`
exports.GRAPHQL_AUTH = `${exports.FEATURE_NAME}/queries`
exports.GRAPHQL_VALIDATE = `${exports.FEATURE_NAME}/validate`
const hooks = require('./hooks')
const { extendsGraphQLSchema } = require('./graphql-schema')
const { authMiddleware } = require('./auth-middleware')

module.exports = ({ registerHook, registerAction }) => {
    registerHook(hooks)
    registerAction({
        hook: '$EXPRESS_GRAPHQL',
        name: hooks.FEATURE_NAME,
        handler: extendsGraphQLSchema,
    })
    registerAction({
        hook: '$EXPRESS_GRAPHQL_MIDDLEWARE',
        name: hooks.FEATURE_NAME,
        handler: authMiddleware,
    })
}

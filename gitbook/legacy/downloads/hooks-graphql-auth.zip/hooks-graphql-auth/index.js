const { runHookApp } = require('@forrestjs/hooks')

runHookApp({
    trace: true,
    settings: ({ setConfig }) => {
        setConfig('expressGraphql.mountPoint', '/graphql')
    },
    services: [
        require('@forrestjs/service-env'),
        require('@forrestjs/service-express'),
        require('@forrestjs/service-express-graphql'),
        require('./graphql-auth'),
    ],
    features: [
        require('./home.route'),
        require('./welcome.query'),
        require('./get-personal-info.query'),
    ]
})


# @marcopeg/react-ssr - frontend example

This code represents the frontent example that is covered in the documentation
of [@marcopeg/react-ssr](https://marcopeg.github.io/react-ssr).

## Quick Start

    npm install
    npm start

